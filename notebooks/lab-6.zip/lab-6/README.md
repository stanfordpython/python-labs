## Lab 6 - NumPy and Object-Oriented Programming!

This is a very short README, but it contains the basic instructions to get started with this lab.

This lab consists of a folder with two iPython notebooks and multiple images (for image processing exercises). To download the entire folder directly from GitHub, run the following at your command line:
```
$ svn checkout https://github.com/stanfordpython/python-labs/trunk/notebooks/lab-6
```

This will download the Lab-6 folder from GitHub into your current directory.

That's all for setup instructions - have fun with the lab! 😊

```
With ❤️ and 🦄,
@coopermj, @psarin
```

(We also owe credit to @sredmond, who wrote today's OOP lab - minor modifications to that lab were made by @coopermj, but it was almost entirely the work of @sredmond).